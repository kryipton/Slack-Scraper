(function () {
    'use strict';

    if (window.slackScraperExtension) {
        // Already running — just show the panel
        const ui = document.getElementById('slack-scraper-ui');
        if (ui) {
            ui.style.display = '';
            const content = ui.querySelector('.scraper-content');
            if (content) content.classList.remove('collapsed');
        }
        return;
    }

    /* ─────────────────────────────────────────────────
       Helper: wait ms
    ───────────────────────────────────────────────── */
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /* ─────────────────────────────────────────────────
       Helper: wait for a DOM element to appear
    ───────────────────────────────────────────────── */
    function waitForElement(selector, timeoutMs = 8000, rootNode = document) {
        return new Promise((resolve, reject) => {
            const existing = rootNode.querySelector(selector);
            if (existing) return resolve(existing);
            const obs = new MutationObserver(() => {
                const el = rootNode.querySelector(selector);
                if (el) { obs.disconnect(); resolve(el); }
            });
            obs.observe(rootNode.body || rootNode, { childList: true, subtree: true });
            setTimeout(() => { obs.disconnect(); reject(new Error(`Timeout waiting for "${selector}"`)); }, timeoutMs);
        });
    }

    /* ─────────────────────────────────────────────────
       Main class
    ───────────────────────────────────────────────── */
    class SlackMessageScraper {
        constructor() {
            this.isScrapingActive = false;
            this.scrapedMessages  = [];
            this.ui               = null;
            this.currentPage      = 1;
            this.totalPages       = 0;
            this.channels         = [];
            this.allChannelResults = [];
            this.exportedFiles    = [];
            this.channelStatuses  = {};   // track per-channel state for UI list
            this.init();
        }

        /* ── Init ────────────────────────────────── */
        init() {
            this.createUI();
            this.setupEventListeners();
            console.log('[SlackScraper] Initialized v3');
        }

        /* ── UI ──────────────────────────────────── */
        createUI() {
            document.getElementById('slack-scraper-ui')?.remove();

            const container = document.createElement('div');
            container.id = 'slack-scraper-ui';
            container.innerHTML = `
                <!-- Header -->
                <div class="scraper-header">
                    <div class="scraper-header-left">
                        <div class="scraper-logo">
                            <svg viewBox="0 0 54 54" xmlns="http://www.w3.org/2000/svg">
                                <path fill="#611f69" d="M19.7 0C16 0 13 3 13 6.7A6.7 6.7 0 0 0 19.7 13.4h6.7V6.7C26.4 3 23.4 0 19.7 0zM19.7 18H6.7A6.7 6.7 0 0 0 0 24.7 6.7 6.7 0 0 0 6.7 31.4H40.2A6.7 6.7 0 0 0 46.9 24.7 6.7 6.7 0 0 0 40.2 18z"/>
                            </svg>
                        </div>
                        <div>
                            <div class="scraper-header h3" style="color:#fff;font-size:13.5px;font-weight:700;margin:0;">Slack Scraper</div>
                            <div class="header-subtitle">Multi-channel export</div>
                        </div>
                    </div>
                    <div class="header-controls">
                        <button id="scraper-toggle" class="toggle-btn" title="Collapse">−</button>
                    </div>
                </div>

                <!-- Body -->
                <div class="scraper-content">

                    <!-- Channels -->
                    <div class="section">
                        <div class="section-label">Channels</div>
                        <div class="input-group" style="margin-bottom:0">
                            <textarea id="channel-input" placeholder="#general&#10;#engineering&#10;#announcements" rows="4"></textarea>
                        </div>
                    </div>

                    <!-- Date range -->
                    <div class="section">
                        <div class="section-label">Date Range</div>
                        <div class="date-row">
                            <div class="input-group">
                                <label for="start-date">From</label>
                                <input type="date" id="start-date" />
                            </div>
                            <div class="input-group">
                                <label for="end-date">To</label>
                                <input type="date" id="end-date" />
                            </div>
                        </div>
                    </div>

                    <!-- Action buttons -->
                    <div class="btn-row">
                        <button id="start-scraping" class="action-btn primary">▶ Start Scraping</button>
                        <button id="test-search" class="action-btn secondary" title="Test search for first channel">⌕ Test</button>
                        <button id="test-pagination" class="action-btn secondary" title="Test page navigation">⇄</button>
                    </div>

                    <!-- Retry warning -->
                    <div class="retry-bar" id="retry-bar">
                        ⚠ Some channels may have loaded slowly. Retry started automatically.
                    </div>

                    <div class="divider"></div>

                    <!-- Status -->
                    <div class="status-section">
                        <div id="status-display">Ready — enter channels and dates above</div>
                        <div id="progress-bar"><div id="progress-fill"></div></div>

                        <!-- Stats -->
                        <div class="stats-grid">
                            <div class="stat-card highlight">
                                <div class="stat-label">Messages</div>
                                <div class="stat-value" id="total-message-count">0</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-label">Channels done</div>
                                <div class="stat-value" id="completed-count">0</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-label">Pages</div>
                                <div class="stat-value" id="pages-processed">0</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-label">Expanded</div>
                                <div class="stat-value" id="expanded-count">0</div>
                            </div>
                        </div>

                        <!-- Active channel pill + page indicator -->
                        <div class="channel-progress-row" id="channel-progress-row" style="display:none">
                            <span class="channel-tag" id="processing-channel">#—</span>
                            <span class="channel-counter" id="channel-counter">0/0</span>
                        </div>
                        <div class="page-info-row" id="page-info-row" style="display:none">
                            <span style="color:#555">page</span>
                            <span class="page-badge" id="current-page">—</span>
                            <span style="color:#555">of</span>
                            <span class="page-badge" id="total-pages">—</span>
                        </div>

                        <!-- Per-channel status list (rendered when scraping starts) -->
                        <div class="channel-list" id="channel-list" style="display:none"></div>
                    </div>

                    <!-- Download Queue -->
                    <div class="downloads-section">
                        <div class="downloads-header">
                            <div class="downloads-title">
                                📦 Downloads
                                <span class="queue-badge empty" id="queue-badge">0</span>
                            </div>
                            <div class="downloads-controls">
                                <button id="download-all-btn" class="action-btn secondary" disabled style="font-size:11px;padding:5px 10px;">↓ All</button>
                                <button id="clear-queue-btn" class="action-btn danger" disabled style="font-size:11px;padding:5px 10px;">✕</button>
                            </div>
                        </div>
                        <div id="export-list" class="export-list">
                            <div class="export-empty" id="export-empty">No files yet — scrape some channels first</div>
                        </div>
                    </div>

                </div><!-- /scraper-content -->
            `;

            document.body.appendChild(container);
            this.ui = container;

            this.exportList    = container.querySelector('#export-list');
            this.downloadAllBtn= container.querySelector('#download-all-btn');
            this.clearQueueBtn = container.querySelector('#clear-queue-btn');
            this.queueBadge    = container.querySelector('#queue-badge');

            this.makeDraggable(container.querySelector('.scraper-header'), container);
        }

        /* ── Events ──────────────────────────────── */
        setupEventListeners() {
            document.getElementById('scraper-toggle').addEventListener('click', () => {
                const content = document.querySelector('.scraper-content');
                const toggle  = document.getElementById('scraper-toggle');
                content.classList.toggle('collapsed');
                toggle.textContent = content.classList.contains('collapsed') ? '+' : '−';
                toggle.title       = content.classList.contains('collapsed') ? 'Expand' : 'Collapse';
            });

            document.getElementById('start-scraping').addEventListener('click', () => this.startMultiChannelScraping());
            document.getElementById('test-search').addEventListener('click',    () => this.testSearchFunction());
            document.getElementById('test-pagination').addEventListener('click',() => this.testNavigationFunction());
            this.downloadAllBtn.addEventListener('click', () => this.downloadAllExports());
            this.clearQueueBtn.addEventListener('click',  () => this.clearQueue());

            // Auto-prefix # to channel names
            document.getElementById('channel-input').addEventListener('input', (e) => {
                const lines = e.target.value.split('\n');
                const cursor = e.target.selectionStart;
                const fixed = lines.map(line => {
                    const t = line.trim();
                    if (t && !t.startsWith('#')) return '#' + t;
                    return t;
                });
                // Only update if something changed (to avoid cursor jump)
                const newVal = fixed.join('\n');
                if (newVal !== e.target.value) {
                    e.target.value = newVal;
                }
            });
        }

        /* ── Drag ────────────────────────────────── */
        makeDraggable(handle, element) {
            let isDragging = false, startX, startY, initialX, initialY;
            handle.addEventListener('mousedown', (e) => {
                if (e.target.closest('button')) return; // don't drag on toggle/controls
                isDragging = true;
                startX = e.clientX; startY = e.clientY;
                initialX = element.offsetLeft; initialY = element.offsetTop;
                document.addEventListener('mousemove', drag);
                document.addEventListener('mouseup',   stopDrag);
            });
            function drag(e) {
                if (!isDragging) return;
                element.style.left = (initialX + e.clientX - startX) + 'px';
                element.style.top  = (initialY + e.clientY - startY) + 'px';
                element.style.right = 'auto';
            }
            function stopDrag() {
                isDragging = false;
                document.removeEventListener('mousemove', drag);
                document.removeEventListener('mouseup',   stopDrag);
            }
        }

        /* ══════════════════════════════════════════
           SCRAPING CORE
        ══════════════════════════════════════════ */

        /* ── Validate inputs ─────────────────────── */
        validateInputs() {
            const channelText = document.getElementById('channel-input').value.trim();
            if (!channelText) return { isValid: false, error: 'Enter at least one channel name' };

            const channels = channelText.split('\n')
                .map(l => l.trim()).filter(Boolean)
                .map(c => c.startsWith('#') ? c : '#' + c);

            if (!channels.length) return { isValid: false, error: 'No valid channels found' };

            const startDate = document.getElementById('start-date').value;
            const endDate   = document.getElementById('end-date').value;

            if (!startDate || !endDate) return { isValid: false, error: 'Both start and end dates are required' };
            if (new Date(startDate) > new Date(endDate)) return { isValid: false, error: 'Start date must be before end date' };

            return { isValid: true, channels, startDate, endDate };
        }

        generateSearchQuery(channel, startDate, endDate) {
            return `after:${startDate} before:${endDate} in:${channel}`;
        }

        /* ── Search modal helpers ────────────────── */
        findSearchModal() {
            for (const dialog of document.querySelectorAll('[role="dialog"]')) {
                if (dialog.hasAttribute('hidden')) continue;
                if (dialog.getAttribute('aria-label') === 'Huddle') continue;
                if (dialog.querySelector('[data-qa="focusable_search_input"], .c-search__input_box, .c-search_modal__wrapper')) {
                    return dialog;
                }
            }
            return null;
        }

        findSearchInput(modal = null) {
            if (!modal) modal = this.findSearchModal();
            if (!modal) return null;
            for (const sel of [
                '[data-qa="focusable_search_input"] .ql-editor[role="combobox"]',
                '[data-qa="focusable_search_input"] .ql-editor',
                '.c-search__input_box .ql-editor',
                '.ql-editor[role="combobox"]'
            ]) {
                const el = modal.querySelector(sel);
                if (el && el.contentEditable === 'true') return el;
            }
            return null;
        }

        async openSearchModal() {
            // Close any existing search modal first to get a clean state
            const existing = this.findSearchModal();
            if (existing) {
                const escEvent = new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true });
                document.dispatchEvent(escEvent);
                await sleep(600);
            }

            this.updateStatus('Opening search modal…', 12);

            // Strategy 1: Ctrl+K
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', keyCode: 75, ctrlKey: true, bubbles: true }));
            await sleep(1500);
            let modal = this.findSearchModal();
            if (modal) return modal;

            // Strategy 2: click the search button
            const searchBtn = document.querySelector('[data-qa="top_nav_search"]');
            if (searchBtn) {
                searchBtn.click();
                await sleep(1800);
                modal = this.findSearchModal();
                if (modal) return modal;
            }

            // Strategy 3: wait up to 5 s for it to appear
            try {
                await waitForElement('[data-qa="focusable_search_input"]', 5000);
                modal = this.findSearchModal();
                if (modal) return modal;
            } catch (_) { /* noop */ }

            throw new Error('Could not open Slack search modal');
        }

        async typeInSearchInput(searchInput, text) {
            // Clear existing content
            searchInput.innerHTML = '<p><br></p>';
            searchInput.focus();
            await sleep(200);

            const paragraph = searchInput.querySelector('p');
            if (!paragraph) { searchInput.textContent = text; return; }

            paragraph.innerHTML = '';
            for (let i = 0; i < text.length; i++) {
                paragraph.textContent += text[i];
                if (i % 3 === 0) searchInput.dispatchEvent(new Event('input', { bubbles: true }));
                await sleep(25);
            }
            searchInput.dispatchEvent(new Event('change', { bubbles: true }));
            searchInput.dispatchEvent(new Event('keyup',  { bubbles: true }));
        }

        /* BUG FIX: wait longer and retry suggestion detection ─────────── */
        async executeSearch(searchInput) {
            this.updateStatus('Waiting for suggestions…', 55);

            // Wait for autocomplete suggestions to appear (up to 4 s, polling)
            let suggestions = [];
            for (let attempt = 0; attempt < 8; attempt++) {
                await sleep(500);
                suggestions = Array.from(document.querySelectorAll(
                    '.c-search_autocomplete__suggestion_item[role="option"]'
                ));
                if (suggestions.length > 0) break;
            }

            let suggestionFound = false;
            for (const s of suggestions) {
                const replacement = s.getAttribute('data-replacement');
                if (replacement) {
                    s.click();
                    suggestionFound = true;
                    this.updateStatus('Selected search suggestion…', 65);
                    break;
                }
            }

            if (!suggestionFound) {
                // Fall back: press Enter
                searchInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
                this.updateStatus('Submitted search query…', 65);
            }

            // BUG FIX: wait for results to actually load — poll for result elements
            this.updateStatus('Loading search results…', 70);
            for (let attempt = 0; attempt < 12; attempt++) {
                await sleep(500);
                const results = document.querySelectorAll(
                    '.c-search_message_result, .c-search_result__message, [data-qa="search_result"]'
                );
                if (results.length > 0) break;
                if (attempt === 6) {
                    // Half-way: try pressing Enter again (sometimes needed for cold load)
                    searchInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
                }
            }

            await sleep(800); // final settle time
        }

        async applySearchFilters(searchQuery) {
            this.updateStatus('Opening search…', 10);
            const modal = await this.openSearchModal();

            this.updateStatus('Locating search input…', 20);
            await sleep(600);

            // BUG FIX: retry finding the search input (sometimes modal renders slowly)
            let searchInput = null;
            for (let attempt = 0; attempt < 6; attempt++) {
                searchInput = this.findSearchInput(modal);
                if (searchInput) break;
                await sleep(400);
            }
            if (!searchInput) throw new Error('Could not find the search input field');

            this.updateStatus('Typing search query…', 35);
            // BUG FIX: clear existing text first
            searchInput.innerHTML = '<p><br></p>';
            await sleep(300);
            await this.typeInSearchInput(searchInput, searchQuery);

            await this.executeSearch(searchInput);

            this.updateStatus('Applying sort: Oldest first…', 75);
            await this.applySortByOldest();

            return true;
        }

        /* ── Sort ────────────────────────────────── */
        findSortButton() {
            return Array.from(document.querySelectorAll('button'))
                .find(b => b.textContent && b.textContent.includes('Sort:'));
        }

        async applySortByOldest() {
            await sleep(1500);
            const sortButton = this.findSortButton();
            if (!sortButton) return false;
            if (sortButton.textContent.includes('Oldest')) return true;

            sortButton.click();
            await sleep(1000);

            const oldestOption = await this.findOldestOption();
            if (!oldestOption) return false;

            oldestOption.click();
            this.updateStatus('Sorting by oldest…', 78);
            await sleep(2000);
            return true;
        }

        async findOldestOption() {
            for (let i = 0; i < 5; i++) {
                const dropdown = document.querySelector('.c-select_options_list, [role="listbox"]');
                if (dropdown) {
                    const option = dropdown.querySelector('[data-qa="timestamp_asc"]') ||
                        Array.from(dropdown.querySelectorAll('[role="option"]'))
                             .find(o => o.textContent.includes('Oldest'));
                    if (option) return option;
                }
                await sleep(300);
            }
            return null;
        }

        /* ── Pagination ──────────────────────────── */
        getPaginationInfo() {
            const wrapper = document.querySelector('.c-pagination_wrapper');
            if (!wrapper) return { currentPage: 1, totalPages: 1, hasNext: false, hasPrev: false };

            let currentPage = 1;
            const attr = wrapper.getAttribute('data-qa-current-page');
            if (attr) {
                currentPage = parseInt(attr) || 1;
            } else {
                const active = wrapper.querySelector('.c-pagination__page_btn--active');
                if (active) currentPage = parseInt(active.textContent.trim()) || 1;
            }

            let totalPages = 1;
            wrapper.querySelectorAll('.c-pagination__page_btn').forEach(btn => {
                const n = parseInt(btn.textContent.trim());
                if (!isNaN(n) && n > totalPages) totalPages = n;
            });

            const nextBtn = wrapper.querySelector('[data-qa="c-pagination_forward_btn"]');
            const prevBtn = wrapper.querySelector('[data-qa="c-pagination_back_btn"]');
            const hasNext = nextBtn && nextBtn.getAttribute('aria-disabled') !== 'true';
            const hasPrev = prevBtn && prevBtn.getAttribute('aria-disabled') !== 'true';

            if (hasNext && currentPage >= totalPages) totalPages = Math.max(totalPages, currentPage + 1);

            return { currentPage, totalPages, hasNext, hasPrev };
        }

        async navigateToFirstPage() {
            const info = this.getPaginationInfo();
            if (info.currentPage === 1) { this.updatePageInfo(1, info.totalPages); return true; }

            this.updateStatus('Navigating to first page…', 83);
            return this.navigateToPage(1);
        }

        async navigateToPage(targetPage) {
            try {
                const current = this.getPaginationInfo();
                if (current.currentPage === targetPage) return true;

                const btn = document.querySelector(`[data-qa="c-pagination_page_btn_${targetPage}"]`);
                if (btn) {
                    btn.click();
                    await sleep(1500);
                    if (this.getPaginationInfo().currentPage === targetPage) {
                        this.currentPage = targetPage;
                        this.updatePageInfo(targetPage, this.getPaginationInfo().totalPages);
                        return true;
                    }
                }

                const isForward = targetPage > current.currentPage;
                const selector  = isForward ? '[data-qa="c-pagination_forward_btn"]' : '[data-qa="c-pagination_back_btn"]';
                const maxSteps  = Math.abs(targetPage - current.currentPage) + 3;

                for (let step = 0; step < maxSteps; step++) {
                    const nav = document.querySelector(selector);
                    if (!nav || nav.getAttribute('aria-disabled') === 'true') break;
                    nav.click();
                    await sleep(1200);
                    const newInfo = this.getPaginationInfo();
                    if (newInfo.currentPage === targetPage) {
                        this.currentPage = targetPage;
                        this.updatePageInfo(targetPage, newInfo.totalPages);
                        return true;
                    }
                    if (newInfo.currentPage === current.currentPage) break; // stuck
                }
                return false;
            } catch (e) { console.error('navigateToPage error:', e); return false; }
        }

        async goToNextPage() {
            try {
                const info = this.getPaginationInfo();
                if (!info.hasNext) return false;

                const nextBtn = document.querySelector('[data-qa="c-pagination_forward_btn"]');
                if (!nextBtn || nextBtn.getAttribute('aria-disabled') === 'true') return false;

                nextBtn.click();
                await sleep(1200);

                for (let i = 0; i < 10; i++) {
                    const newInfo = this.getPaginationInfo();
                    if (newInfo.currentPage > this.currentPage) {
                        this.currentPage = newInfo.currentPage;
                        this.totalPages  = Math.max(this.totalPages, newInfo.totalPages);
                        this.updatePageInfo(this.currentPage, this.totalPages);
                        return true;
                    }
                    await sleep(300);
                }
                return false;
            } catch (e) { console.error('goToNextPage error:', e); return false; }
        }

        /* ── Expand "Show more" ───────────────────── */
        findShowMoreButtons() {
            return Array.from(document.querySelectorAll(
                'button.c-search__expand, button[data-qa="unstyled-button"]'
            )).filter(b => {
                const t = b.textContent;
                return t && (t.includes('Show more') || t.includes('...') || b.querySelector('.c-search__expand_ellipsis'));
            });
        }

        async expandAllMessages() {
            try {
                await sleep(800);
                let expandedCount = 0;
                for (let pass = 0; pass < 2; pass++) {
                    const buttons = this.findShowMoreButtons();
                    if (!buttons.length) break;
                    for (let i = 0; i < buttons.length; i++) {
                        const btn = buttons[i];
                        if (btn.offsetParent !== null && !btn.disabled) {
                            if (i % 10 === 0) { btn.scrollIntoView({ behavior: 'instant', block: 'center' }); await sleep(80); }
                            btn.click();
                            expandedCount++;
                            if (i % 5 === 0) await sleep(150);
                        }
                    }
                    await sleep(600);
                }
                return expandedCount;
            } catch (e) { console.error('expandAllMessages error:', e); return 0; }
        }

        /* ── Extract messages from DOM ───────────── */
        extractMessages() {
            const results = [];
            const elements = document.querySelectorAll(
                '.c-search_message_result, .c-search_result__message, [data-qa="search_result"], .c-virtual_list__item, .c-message_kit__message'
            );

            elements.forEach((el, idx) => {
                try {
                    const msg = this.parseMessageElement(el);
                    if (msg && (msg.content || msg.sender)) {
                        results.push({ id: idx, ...msg });
                    }
                } catch (e) { /* skip */ }
            });
            return results;
        }

        parseMessageElement(el) {
            const msg = { sender: '', content: '', timestamp: '', channel: '' };

            const senderEl = el.querySelector('[data-qa="message_sender_name"], .c-message__sender, .c-message_kit__sender_name, .c-message_sender_name');
            if (senderEl) msg.sender = senderEl.textContent.trim();

            const channelEl = el.querySelector('[data-qa="search_result_channel_name"] .c-channel_entity__name, .c-inline_channel_entity__name, .c-channel_entity__name');
            if (channelEl) msg.channel = channelEl.textContent.trim();

            const contentEl = el.querySelector('[data-qa="message-text"], .c-message__message_blocks, .c-search_result__message_body, .c-message_kit__text, .c-message__body');
            if (contentEl) msg.content = contentEl.textContent.replace(/\.\.\./g, '').replace(/Show more/g, '').replace(/\s+/g, ' ').trim();

            const tsEl = el.querySelector('.c-timestamp, [data-qa="message_timestamp"], .c-message_kit__timestamp, time');
            if (tsEl) msg.timestamp = tsEl.getAttribute('datetime') || tsEl.getAttribute('title') || tsEl.textContent.trim();

            return msg;
        }

        /* ── Process all pages for one channel ────── */
        async processAllPages() {
            let allMessages  = [];
            let totalExpanded = 0;
            let pagesProcessed = 0;

            this.updateStatus('Navigating to first page…', 82);
            await this.navigateToFirstPage();

            const initialInfo  = this.getPaginationInfo();
            this.currentPage   = initialInfo.currentPage;
            this.totalPages    = initialInfo.totalPages;
            this.updatePageInfo(this.currentPage, this.totalPages);

            let hasMore = true;
            let failures = 0;
            const maxFailures = 3;

            while (hasMore && failures < maxFailures) {
                const progress = 85 + (pagesProcessed / Math.max(this.totalPages, pagesProcessed + 1)) * 10;
                this.updateStatus(`Extracting page ${this.currentPage}${this.totalPages > 1 ? `/${this.totalPages}` : ''}…`, progress);

                await sleep(900);

                const expanded = await this.expandAllMessages();
                totalExpanded += expanded;
                this.updateStat('expanded-count', totalExpanded);

                const pageMessages = this.extractMessages();
                pageMessages.forEach(m => { m.pageNumber = this.currentPage; m.totalPages = this.totalPages; });
                allMessages = allMessages.concat(pageMessages);
                pagesProcessed++;
                this.updateStat('pages-processed', pagesProcessed);

                const paginationInfo = this.getPaginationInfo();
                if (paginationInfo.hasNext) {
                    this.updateStatus(`Navigating to page ${this.currentPage + 1}…`, progress + 2);
                    const navigated = await this.goToNextPage();
                    if (navigated) {
                        failures = 0;
                        const latest = this.getPaginationInfo();
                        this.totalPages = Math.max(this.totalPages, latest.totalPages, this.currentPage);
                        this.updatePageInfo(this.currentPage, this.totalPages);
                    } else {
                        failures++;
                    }
                } else {
                    hasMore = false;
                }
            }

            return allMessages;
        }

        /* ── Process single channel ──────────────── */

        /**
         * Process one channel. If the first attempt returns 0 messages it
         * automatically retries once with a longer wait (fixes the cold-cache bug).
         */
        async processSingleChannel(channel, startDate, endDate) {
            const run = async (attempt) => {
                const query = this.generateSearchQuery(channel, startDate, endDate);

                this.updateStat('expanded-count', 0);
                this.updateStat('pages-processed', 0);
                this.updatePageInfo('—', '—');
                this.updateStat('message-count', 0);
                this.updateStatus(`${attempt > 1 ? '↺ Retry — processing ' : 'Processing '}${channel}…`, 5);

                await this.applySearchFilters(query);

                this.updateStatus(`Extracting messages from ${channel}…`, 85);
                const messages = await this.processAllPages();

                messages.forEach(m => { m.sourceChannel = channel; });

                return {
                    channel,
                    messages,
                    messageCount:   messages.length,
                    expandedCount:  parseInt(document.getElementById('expanded-count').textContent) || 0,
                    pagesProcessed: parseInt(document.getElementById('pages-processed').textContent) || 0
                };
            };

            let result = await run(1);

            // BUG FIX: if 0 messages on first run — retry once with a longer pause
            if (result.messageCount === 0) {
                this.showRetryBar(true);
                console.warn(`[SlackScraper] 0 messages for ${channel} — retrying after pause`);
                await sleep(3000);
                result = await run(2);
                this.showRetryBar(false);
            }

            return result;
        }

        /* ── Main orchestrator ───────────────────── */
        async startMultiChannelScraping() {
            if (this.isScrapingActive) return;

            const validation = this.validateInputs();
            if (!validation.isValid) {
                this.updateStatus(`⚠ ${validation.error}`, 0);
                return;
            }

            this.isScrapingActive = true;
            this.allChannelResults = [];
            document.getElementById('start-scraping').disabled = true;

            const { channels, startDate, endDate } = validation;
            this.channels = channels;

            // Build channel list UI
            this.initChannelList(channels);

            this.updateStat('completed-count', 0);
            this.updateStat('total-message-count', 0);
            this.showChannelProgressRow(false);

            let totalMessages = 0;

            try {
                for (let i = 0; i < channels.length; i++) {
                    const channel = channels[i];
                    this.updateChannelList(channel, 'active');
                    this.showActiveChannel(channel, i + 1, channels.length);
                    this.updateStatus(`Channel ${i + 1}/${channels.length}: ${channel}`, 0);

                    try {
                        const result = await this.processSingleChannel(channel, startDate, endDate);
                        this.allChannelResults.push(result);
                        totalMessages += result.messageCount;

                        this.updateStat('completed-count', i + 1);
                        this.updateStat('total-message-count', totalMessages);
                        this.updateChannelList(channel, 'done', result.messageCount);

                        this.exportSingleChannel(result, startDate, endDate);

                        this.updateStatus(`✓ ${channel} — ${result.messageCount} messages`, 100);

                        if (i < channels.length - 1) await sleep(2500); // gap between channels
                    } catch (e) {
                        console.error(`[SlackScraper] Failed channel ${channel}:`, e);
                        this.updateStatus(`✗ ${channel}: ${e.message}`, 0);
                        this.updateChannelList(channel, 'error');
                        // Continue with remaining channels
                    }
                }

                // Combined export if >1 channel
                if (this.allChannelResults.length > 1) this.exportAllChannels(startDate, endDate);

                this.updateStatus(
                    `✓ Done — ${totalMessages} messages across ${this.allChannelResults.length} channel${this.allChannelResults.length !== 1 ? 's' : ''}`,
                    100
                );
                this.showActiveChannel(null);

            } catch (e) {
                console.error('[SlackScraper] Fatal error:', e);
                this.updateStatus(`✗ Error: ${e.message}`, 0);
            } finally {
                this.isScrapingActive = false;
                document.getElementById('start-scraping').disabled = false;
            }
        }

        /* ── Export ──────────────────────────────── */
        exportSingleChannel(result, startDate, endDate) {
            const exportData = {
                exportedAt:    new Date().toISOString(),
                channel:       result.channel,
                totalMessages: result.messageCount,
                dateRange:     { start: startDate, end: endDate },
                sortedBy:      'oldest',
                pagesProcessed: result.pagesProcessed,
                expandedCount: result.expandedCount,
                messages:      result.messages
            };
            const filename = `slack-${result.channel.replace('#', '')}-${startDate}-to-${endDate}.json`;
            this.addToDownloadQueue(filename, exportData, `${result.messageCount} messages from ${result.channel}`);
        }

        exportAllChannels(startDate, endDate) {
            const combinedData = {
                exportedAt:    new Date().toISOString(),
                totalChannels: this.allChannelResults.length,
                totalMessages: this.allChannelResults.reduce((s, r) => s + r.messageCount, 0),
                dateRange:     { start: startDate, end: endDate },
                sortedBy:      'oldest',
                channels:      this.allChannelResults.map(r => ({ channel: r.channel, messageCount: r.messageCount })),
                allMessages:   this.allChannelResults.flatMap(r => r.messages)
            };
            const filename = `slack-all-channels-${startDate}-to-${endDate}.json`;
            this.addToDownloadQueue(filename, combinedData, `Combined: ${combinedData.totalMessages} messages from ${this.allChannelResults.length} channels`);
        }

        /* ── Download queue ──────────────────────── */
        addToDownloadQueue(filename, exportData, description) {
            const dataStr = JSON.stringify(exportData, null, 2);
            const blob    = new Blob([dataStr], { type: 'application/json' });
            const url     = URL.createObjectURL(blob);

            const item = {
                id:          Date.now() + Math.random(),
                filename,
                url,
                blob,
                description,
                size:        this.formatFileSize(blob.size),
                createdAt:   new Date().toLocaleTimeString()
            };

            this.exportedFiles.push(item);
            this.renderExportItem(item);
            this.updateQueueInfo();
        }

        renderExportItem(item) {
            // Remove empty placeholder
            document.getElementById('export-empty')?.remove();

            const div = document.createElement('div');
            div.className = 'export-item';
            div.setAttribute('data-id', item.id);
            div.innerHTML = `
                <div class="export-icon">📄</div>
                <div class="export-info">
                    <div class="export-filename">${item.filename}</div>
                    <div class="export-meta">${item.description} · ${item.size} · ${item.createdAt}</div>
                </div>
                <div class="export-actions">
                    <button class="export-btn download" title="Download">↓</button>
                    <button class="export-btn remove"   title="Remove">✕</button>
                </div>
            `;
            div.querySelector('.download').addEventListener('click', () => this.downloadSingle(item.id));
            div.querySelector('.remove').addEventListener('click',   () => this.removeSingle(item.id));
            this.exportList.appendChild(div);
        }

        downloadSingle(id) {
            const item = this.exportedFiles.find(i => i.id === id);
            if (item) this.downloadFile(item.filename, item.blob);
        }

        async downloadFile(filename, blob) {
            if (chrome && chrome.runtime) {
                try {
                    const text = await blob.text();
                    chrome.runtime.sendMessage({ action: 'downloadFile', filename, data: text, mimeType: 'application/json' }, (res) => {
                        if (!res?.success) this.fallbackDownload(filename, blob);
                    });
                    return;
                } catch (_) { /* fall through */ }
            }
            this.fallbackDownload(filename, blob);
        }

        fallbackDownload(filename, blob) {
            const url  = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url; link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        }

        removeSingle(id) {
            const idx = this.exportedFiles.findIndex(i => i.id === id);
            if (idx === -1) return;
            URL.revokeObjectURL(this.exportedFiles[idx].url);
            this.exportedFiles.splice(idx, 1);
            this.exportList.querySelector(`[data-id="${id}"]`)?.remove();
            if (!this.exportedFiles.length) {
                const empty = document.createElement('div');
                empty.id = 'export-empty';
                empty.className = 'export-empty';
                empty.textContent = 'No files yet — scrape some channels first';
                this.exportList.appendChild(empty);
            }
            this.updateQueueInfo();
        }

        downloadAllExports() {
            this.exportedFiles.forEach((item, i) => setTimeout(() => this.downloadSingle(item.id), i * 400));
        }

        clearQueue() {
            if (!this.exportedFiles.length) return;
            if (!confirm(`Clear ${this.exportedFiles.length} file(s) from download queue?`)) return;
            this.exportedFiles.forEach(i => URL.revokeObjectURL(i.url));
            this.exportedFiles = [];
            this.exportList.innerHTML = '';
            const empty = document.createElement('div');
            empty.id = 'export-empty'; empty.className = 'export-empty';
            empty.textContent = 'No files yet — scrape some channels first';
            this.exportList.appendChild(empty);
            this.updateQueueInfo();
        }

        updateQueueInfo() {
            const count = this.exportedFiles.length;
            this.queueBadge.textContent = count;
            this.queueBadge.className   = `queue-badge${count ? '' : ' empty'}`;
            this.downloadAllBtn.disabled = count === 0;
            this.clearQueueBtn.disabled  = count === 0;
        }

        formatFileSize(bytes) {
            if (!bytes) return '0 B';
            const k = 1024, units = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + units[i];
        }

        /* ── UI helpers ──────────────────────────── */
        updateStatus(message, progress = 0) {
            const el = document.getElementById('status-display');
            const pb = document.getElementById('progress-fill');
            if (el) el.textContent = message;
            if (pb) pb.style.width = Math.min(100, progress) + '%';
        }

        updateStat(id, value) {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        }

        updatePageInfo(current, total) {
            document.getElementById('current-page').textContent = current;
            document.getElementById('total-pages').textContent  = total;
            const row = document.getElementById('page-info-row');
            if (row) row.style.display = '';
        }

        showActiveChannel(channel, idx = 0, total = 0) {
            const row = document.getElementById('channel-progress-row');
            if (!channel) { if (row) row.style.display = 'none'; return; }
            if (row) row.style.display = '';
            const tag = document.getElementById('processing-channel');
            const ctr = document.getElementById('channel-counter');
            if (tag) tag.textContent = channel;
            if (ctr) ctr.textContent = `${idx}/${total}`;
        }

        showChannelProgressRow(show) {
            const row = document.getElementById('channel-progress-row');
            if (row) row.style.display = show ? '' : 'none';
        }

        showRetryBar(visible) {
            const bar = document.getElementById('retry-bar');
            if (bar) bar.classList.toggle('visible', visible);
        }

        /* ── Per-channel status list ─────────────── */
        initChannelList(channels) {
            const list = document.getElementById('channel-list');
            if (!list) return;
            list.innerHTML = '';
            list.style.display = '';
            this.channelStatuses = {};
            channels.forEach(ch => {
                this.channelStatuses[ch] = 'pending';
                const item = document.createElement('div');
                item.className = 'channel-list-item pending';
                item.id = 'ch-item-' + ch.replace(/[^a-zA-Z0-9]/g, '_');
                item.innerHTML = `<span class="ch-status"></span><span class="ch-name">${ch}</span><span class="ch-count"></span>`;
                list.appendChild(item);
            });
        }

        updateChannelList(channel, status, count = null) {
            const id  = 'ch-item-' + channel.replace(/[^a-zA-Z0-9]/g, '_');
            const el  = document.getElementById(id);
            if (!el) return;
            el.className = `channel-list-item ${status}`;
            if (count !== null) {
                const cEl = el.querySelector('.ch-count');
                if (cEl) cEl.textContent = `${count} msg`;
            }
        }

        /* ── Test helpers ────────────────────────── */
        async testSearchFunction() {
            const v = this.validateInputs();
            if (!v.isValid) { this.updateStatus(`⚠ ${v.error}`, 0); return; }
            try {
                this.updateStatus('Testing search…', 0);
                await this.applySearchFilters(this.generateSearchQuery(v.channels[0], v.startDate, v.endDate));
                this.updateStatus('✓ Search test passed', 100);
            } catch (e) {
                this.updateStatus(`✗ Test failed: ${e.message}`, 0);
            }
        }

        async testNavigationFunction() {
            try {
                this.updateStatus('Testing navigation…', 0);
                const ok1 = await this.navigateToFirstPage();
                if (!ok1) { this.updateStatus('✗ First-page navigation failed', 0); return; }
                this.updateStatus('✓ First page — testing next…', 50);
                const info = this.getPaginationInfo();
                if (info.hasNext) {
                    const ok2 = await this.goToNextPage();
                    this.updateStatus(ok2 ? '✓ Navigation test passed' : '✗ Next page navigation failed', ok2 ? 100 : 0);
                } else {
                    this.updateStatus('✓ Navigation test passed (single page)', 100);
                }
            } catch (e) {
                this.updateStatus(`✗ Navigation test failed: ${e.message}`, 0);
            }
        }
    }

    // Boot
    window.slackScraperExtension = new SlackMessageScraper();

})();
